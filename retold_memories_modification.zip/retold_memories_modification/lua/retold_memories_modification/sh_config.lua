RETOLD.Modification = RETOLD.Modification or {}

-- Ajoutez ici vos fichiers si vous voulez centraliser les réglages.
