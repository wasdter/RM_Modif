RETOLD.AddSurvivor({
    id = "custom_survivor",
    name = "Custom Survivor",

    -- Identifiant de la Pill externe.
    pill = "",

    -- Lien Imgur utilisé comme référence d'icône.
    icon = "https://i.imgur.com/placeholder.png",

    -- Modèle utilisé pour le preview et comme fallback sans base Pills.
    model = "models/player/Group01/male_04.mdl",
    previewModel = "models/player/Group01/male_04.mdl",

    walkSpeed = 220,
    runSpeed = 380,

    camera = {
        distance = 140,
        height = 35
    },

    lastSurvivorMusic = ""
})
