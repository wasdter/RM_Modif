RETOLD.AddKiller({
    id = "custom_killer",
    name = "Custom Killer",

    pill = "",
    icon = "https://i.imgur.com/placeholder.png",

    model = "models/player/Group03/male_09.mdl",
    previewModel = "models/player/Group03/male_09.mdl",

    walkSpeed = 250,
    runSpeed = 430,

    camera = {
        distance = 180,
        height = 55
    }
})
