if not RETOLD then return end

include("retold_memories_modification/sh_config.lua")
include("retold_memories_modification/survivors/sh_example_survivor.lua")
include("retold_memories_modification/killers/sh_example_killer.lua")
